using System;

namespace Pregunta1
{
	public enum Estado
	{
		ADMITIDO, NO_ADMITIDO,SIN_EVALUACIÓN
	}
}