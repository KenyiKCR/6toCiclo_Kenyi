namespace Pregunta2{
	public enum Genero{
		FOLKLORE, CLASICA
	}
}